annotatePeaks.pl RenLab-CTCF-cerebellum_8weeks_peaks.bed mm9     > HOMER_CTCF-cerebellum_8weeks.xls
annotatePeaks.pl RenLab-CTCF-heart_8weeks_peaks.bed mm9          > HOMER_CTCF-heart_8weeks.xls
annotatePeaks.pl RenLab-CTCF-liver_8weeks_peaks.bed mm9          > HOMER_CTCF-liver_8weeks.xls
annotatePeaks.pl RenLab-CTCF-olfactory-bulb_8weeks_peaks.bed mm9 > HOMER_CTCF-olfactory-bulb.xls
