setwd('/Volumes/MyBook_3/BD_aging_project/Machine_learning_aging/Predict_level/RNA_FPKM/')

library("DESeq2")

# 2016-08-02
# examine number of significant genes at different threshold (recommended by Anshul)

##################################################################################### 
### READ ALL MATRICES

my.cereb <- read.csv("2015-12-08_CEREBELLUM_FPKM_matrix_forML.txt",sep="\t",header=T)
"2015-12-08_HEART_FPKM_matrix_forML.txt"
"2015-12-08_LIVER_FPKM_matrix_forML.txt"
"2015-12-08_NPCs_FPKM_matrix_forML.txt"
"2015-12-08_OLFACTORY_BULB_FPKM_matrix_forML.txt"